# from dotenv import find_dotenv, load_dotenv
from transformers import pipeline
import streamlit as st
from langchain import PromptTemplate, LLMChain, OpenAI


# load_dotenv(find_dotenv())


def img2text(url):
    imagetotext = pipeline("image-to-text" , model = "Salesforce/blip-image-captioning-large")

    text = imagetotext(url)[0]["generated_text"]

    print(text)
    return text

def generate_story(scenario):
    template = """
    you are a story teller:
    you can generate a short story based on a simple narrative, the story should be no more than 20 words;

    Context: {scenario}
    Story:
    """

    prompt = PromptTemplate(template=template, input_variables=["scenario"])

    story_llm = LLMChain(llm=OpenAI( 
        openai_api_key = 'sk-proj-97L1BDaFbgwfORdT3Dx9T3BlbkFJgdseWdwniD60jci5QZ3U',
        model_name = "gpt-3.5-turbo", temperature=1), prompt=prompt, verbose=True)
    
    story = story_llm(scenario=scenario)

    return story

# def text2speech(message):
#     API_Url = "https://api-inference.huggingface.co/models/espnet/kan-bayashi_ljspeech_vits"
#     headers = {"Authorization": f"Bearer {huggingfacetoken}"}
#     payloads = {
#         "inputs": message
#     }
#     response = requests.post(API_Url, headers=headerz, json=payloads)
#     with open('audio.flac', 'wb') as file:
#         file.write(response.content)

def main():

    st.title("Visual-AI ChatBot")
    st.header("Please upload an image:")

    uploadfile = st.file_uploader("", type="jpg")
    if uploadfile is not None:
        bytes_data = uploadfile.getvalue()
        with open(uploadfile.name, "wb") as file:
            file.write(bytes_data) 
        st.image(uploadfile, caption='Uploaded Image.',
                 use_column_width=True)
        scenario = img2text(uploadfile.name)
        # story = generate_story(scenario)
        # text2speech(scenario)

        with st.expander("Scenario about Image"):
            st.write("Upon examining the image closely, we see ", scenario)

        # st.audio("audio.flac")
        # with st.expander("story"):
        #     st.write(story)

if __name__ == '__main__':
    main()